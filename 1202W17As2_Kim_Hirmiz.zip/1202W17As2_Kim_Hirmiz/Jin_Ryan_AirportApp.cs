﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace _1202W17As2_Kim_Hirmiz
{
    class AirportApp
    {
        static void Main(string[] args)
        {
            //COMP1202, 101058670, Kim Jin
            WriteLine("|");
            WriteLine("||");
            WriteLine("||||||||||||||||||||||||||||||||||||||");
            WriteLine("|||||  Welcome to the JaiR Airlines! ||||||||");
            WriteLine("|||||||||||||||||||||||||||||||||||||||||||||||||\n");



            string Name;
            double Charge;

            //COMP1202, 101086605, Hirmiz Ryan
            Airport choice = new Airport();
            do
            {
                Name = AskForName();
                Console.Write("Enter charge amount: ");
                Charge = Convert.ToDouble(Console.ReadLine());
   
                choice.askForInfo(Charge);
                do
                {
                    choice.displayTing();
                } while (AskForMenu() == 2);
            } while (AskForMenu() == 1);
            /*switch(AskForMenu())
            {
                case 1:
                    Name = AskForName();
                    Console.Write("Enter charge amount: ");
                    Charge = Convert.ToDouble(Console.ReadLine());
                    choice.askForInfo(Charge);
                    break;
                case 2:
                    choice.displayTing();
                    break;
            }*/
      
            ReadKey();
        }

        //COMP1202, 101058670, Kim Jin
        public static int AskForMenu()
        {
            string aValue;
            int Choice;
            WriteLine("Please select the menu(with number).");
            WriteLine("Add Airport Data: 1\nDisplay Statistical Report: 2");
            WriteLine("Exit: 3");
            aValue = ReadLine();
            Choice = Convert.ToInt32(aValue);
            return Choice;
        }

        //COMP1202, 101086605, Hirmiz Ryan
        public static string AskForName()
        {
            string Title;
            Write("What's the name of airport you taking?: ");
            Title = ReadLine();
            while (Title == "")
            {
                Write("Please Enter the Name!: ");
                Title = ReadLine();
            }
            return Title;
        }

    }
}
