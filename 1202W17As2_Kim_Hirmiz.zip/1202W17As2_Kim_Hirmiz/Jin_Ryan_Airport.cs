﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1202W17As2_Kim_Hirmiz
{
    class Airport
    {
        //COMP1202, 101058670, Kim Jin
        private int menu;
        private string name;
        private double charge;

        private string[] month = { "January", "February",  "March", "April", "May",
       "June", "July", "August", "September", "October", "November", "December" };
        private int[] flight = new int[12];
        private int[] passenger = new int[12];
        private double[] totalRevenueAmount { get; set; } = new double[12];

        //COMP1202, 101086605, Hirmiz Ryan
        public Airport()
        {

        }
        public Airport(string n, double c)
        {
            name = n;
            charge = c;

        }

        //COMP1202, 101058670, Kim Jin
        public double getMoney(int x, double y)
        {
            return x * y;
        }

        //Ryan Hirmiz, 101086605
        public void askForInfo(double amount)
        {

            for (int i = 0; i < month.Length; i++)
            {
                Console.Write("Enter info for the month of: " + month[i]);
                Console.Write("\nEnter amount of flights:");
                var toVal2 = validateNumbers(Convert.ToInt32(Console.ReadLine()));
                flight[i] = toVal2;


                Console.Write("Enter amount of passengers: ");
                var toVal = validateNumbers(Convert.ToInt32(Console.ReadLine()));
                passenger[i] = toVal;

                totalRevenueAmount[i] = getMoney(flight[i], amount);
            }
        }

        //COMP1202, 101058670, Kim Jin
        public int validateNumbers(int z)
        {
            while (true)
            {
                if (z > -1)
                {
                    Console.WriteLine("\nPassed!\n");
                    break;
                }
                else
                {
                    Console.WriteLine("Number cannot be negative, enter again:");
                    z = Convert.ToInt32(Console.ReadLine());
                    continue;
                }

            }
            return z;
        }

        //COMP1202, 101086605, Hirmiz Ryan
        public void displayTing()
        {
            for (int j = 0; j < month.Length; j++)
            {
                Console.WriteLine("Month of: " + month[j]);
                Console.WriteLine("flights: " + flight[j]);
                Console.WriteLine("passengers: " + passenger[j]);
                Console.WriteLine("Revenue:  " + totalRevenueAmount[j]);
                Console.WriteLine("\n");
            }
        }

        //COMP1202, 101058670, Kim Jin
        public static decimal AskForCharge()
        {
            decimal Charge;
            Console.Write("How much are you spending?: ");
            Charge = Convert.ToDecimal(Console.ReadLine());

            return Charge;
        }
        //COMP1202, 101086605, Hirmiz Ryan
        public int Menu
        {
            get
            {
                return menu;
            }
            set
            {
                menu = value;
            }
        }
        //COMP1202, 101058670, Kim Jin
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        //COMP1202, 101086605, Hirmiz Ryan
        public double Charge
        {
            get
            {
                return charge;
            }
            set
            {
                charge = value;
            }
        }
        //COMP1202, 101058670, Kim Jin
        public int[] Passenger
        {
            get
            {
                return passenger;
            }
            set
            {
                passenger = value;
            }
        }
        //COMP1202, 101086605, Hirmiz Ryan
        public int[] NoOfPerson
        {
            get
            {
                return passenger;
            }
            set
            {
                passenger = value;
            }
        }
        //COMP1202, 101058670, Kim Jin
        public string[] Month
        {
            get
            {
                return month;
            }
            set
            {
                month = value;
            }
        }
        //COMP1202, 101086605, Hirmiz Ryan
        public int[] Flight
        {
            get
            {
                return flight;
            }
            set
            {
                flight = value;
            }
        }
        //COMP1202, 101058670, Kim Jin
        public double GetRevenue()
        {
            return charge * flight[12];
        }
        public string ReturnList()

        {
            string aSchedule = "Month\t\tInt.\t\tPrin.\t\tNew";
            aSchedule += "\nNo.\t\tPd.\t\tPd.\t\tBalance\n";
            aSchedule += "------\t\t ------\t\t ------\t" + "-----\t";
            //balance = loanAmount;
            int month = 11;
            for (int m = 0; m <= month; m++)
            {
                GetRevenue();
                aSchedule += month + "\t" +
                name + "\t" +
                charge.ToString("C") + "\t" +
                passenger + "\n";
            }
            return aSchedule;
        }
        /*public string GetData()
        {

        }*/

        //COMP1202, 101086605, Hirmiz Ryan
        public override string ToString()
        {
            return "name of Airport: " + name + "\nRunway Charge: " + charge +
                "\nNumber of flight: " + flight + "\nMonth: " + month + "\nTotal: " + GetRevenue().ToString("C2");
        }
    }
}
